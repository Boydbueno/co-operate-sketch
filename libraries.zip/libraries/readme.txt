For information on installing libraries, see: http://www.arduino.cc/en/Guide/Libraries
